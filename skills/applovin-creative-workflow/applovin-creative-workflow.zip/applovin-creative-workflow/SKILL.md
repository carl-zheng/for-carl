---
name: applovin-creative-workflow
description: Plan, write, review, and iterate AppLovin performance-ad video concepts, six-stage scripts, shot lists, subtitles, voiceover, CTA, and end-card handoffs. Use for AppLovin ad creative, 37-second or 60-second direct-response videos, interstitial/rewarded variants, creative briefs, or compliance-aware creative reviews. Do not use for unrelated brand films or generic video editing.
---

# AppLovin Creative Workflow

Build an executable performance-ad package, not a prose-only concept. Preserve the user's product facts, audience, offer, language, duration, and requested deliverable. Never invent ratings, sales, certifications, professional identities, origin claims, earnings, testimonials, discounts, guarantees, or availability.

## Route the task

- For a new concept or script, read [references/workflow.md](references/workflow.md) and [references/stage-cards.md](references/stage-cards.md).
- For template selection, 60-second expansion, interstitial/rewarded adaptation, or fashion/emotional-value products, also read [references/variants.md](references/variants.md).
- For review, compliance checks, or final delivery, read [references/qa-and-compliance.md](references/qa-and-compliance.md).
- For subtitle writing, timing, styling, SRT delivery, or finished-video review, read [references/subtitle-standard.md](references/subtitle-standard.md).
- For voiceover copy length, pacing, TTS generation, or audio/video duration matching, read [references/voiceover-standard.md](references/voiceover-standard.md).
- For KreadoAI production, scene-image video, uploaded character libraries, or a real-person reference rejection, read [references/kreadoai-seedance-character-library.md](references/kreadoai-seedance-character-library.md).
- For any product URL, repeat product, sequel, refresh, or additional creative batch, read [references/history-deduplication.md](references/history-deduplication.md) before ideation or generation.
- For a reusable output structure, read [references/output-template.md](references/output-template.md).

## Input gate

Before production, establish as many of these as the user supplies or can be safely derived from product materials:

1. Completed product/detail-page facts.
2. One primary audience and one primary use scene; a secondary one is optional.
3. Product type, placement, target duration, market, and language.
4. One primary benefit, with optional supporting benefits mapped to the same audience or scene.
5. Verifiable trust evidence and the exact live offer.
6. End-card title/visual/offer rules, if already defined.
7. The canonical product identity and every discoverable prior production for that product, including equivalent URLs, renamed listings, and projects created from the same official product imagery.

If a claim, offer, or proof item is missing, mark it `待确认` and use a clearly labeled placeholder. Do not turn a placeholder into ad-ready copy. Missing inputs do not prevent concept exploration, but they do prevent a final compliance-ready status.

## Core execution

1. Resolve product identity and run the history scan in `history-deduplication.md`. Do not ideate until the prior-work inventory and exclusion set exist.
2. Choose one narrative template and state why it fits.
3. Produce a compact pre-production brief: audience, scene, pain type, primary benefit, trust evidence, offer, S3/S4 timing strategy, and novelty hypothesis against all prior productions.
4. Write S1–S6 with timecode, shot/action, on-screen text, voiceover, and purpose.
5. Make every spoken claim visually demonstrable. S4 must remain understandable with sound off.
6. Copy the final offer wording across S5/S6 CTA, end-card title, and landing/store activity. If the destination wording is unavailable, flag the alignment check as unresolved.
7. Run both the historical novelty gate and the release gate in `qa-and-compliance.md`. Report failed or unverified items explicitly.
8. Produce the voiceover package using `voiceover-standard.md`: duration-based word budget, performance direction, generated-audio duration, and fit result. Write enough useful copy for normal speech; never fill missing copy by slowing the voice.
9. Produce a subtitle package using `subtitle-standard.md`: approved subtitle copy, timed SRT, style specification, and safe-area notes. Check it again against the finished render.
10. Register the approved concept and final asset fingerprints in the product history ledger before delivery, so later runs can exclude them.
11. When KreadoAI is the requested production platform, generate scene footage through Seedance multi-reference video. When a human actor is needed, upload and select the approved person through the user's character/asset library, then combine that `asset_library` reference with the `normal` scene/product references. Treat locally assembled motion graphics as post-production, not as a substitute for requested KreadoAI-generated footage.

## Non-negotiable invariants

- Default canvas: 9:16 vertical.
- Default tested baseline: 37 seconds, `3 + 4 + 8 + 10 + 7 + 5`; treat this as a baseline, not a prison.
- S1 establishes relevance or an outcome gap within 3 seconds; avoid logo/cold brand openings.
- S2 contains one concrete, filmable pain and normally stays at or below 5 seconds.
- S3 shows the product clearly with a human hand/use action. Supporting functions need a clear hierarchy and audience/scene relevance.
- S4 proves the effect through real actions, results, comparison, or multiple use scenes. Repetition must change scene, angle, or operator; never replay the identical shot as filler.
- S5 uses one or two verified trust sources plus one main offer hook; at most add one logistics/threshold hook.
- S6 leaves a clickable composition, avoids a black-frame hard cut, and bridges directly into the end card.
- Full subtitles are the default. Opening subtitle should be immediately readable; keep it concise (the manual's review baseline is no more than 12 Chinese characters).
- English female voiceover defaults to a natural commercial delivery at normal speed: target 150–165 words per minute and generate at the provider's neutral `1.0×` rate (minor 0.98–1.05 adjustment is acceptable after listening). For a fully narrated 37-second video, normally write about 90–100 English words; for 60 seconds, about 145–160. Recalculate for intentional silent beats. Do not use sub-0.95 speed or audio time-stretching to compensate for an underwritten script.
- Subtitles are a separate production deliverable, not an automatic transcript dump. They must be rewritten for screen reading, accurately timed, kept inside the verified CTA/UI safe area, and delivered as complete UTF-8 SRT plus a burned-in ASS layer. Use the locked premium subtitle system and reusable template in `subtitle-standard.md` unless the user explicitly requests another visual identity.
- Do not depict the full ordering flow inside the video; hand the click to the end card/destination.
- Do not recommend manually pausing a winning asset merely to force iteration.
- A repeated URL or product must never reuse a prior concept package or generated video asset. Product facts, verified offer, brand identity, and compliance language may remain stable; the creative promise, hook mechanism, narrative route, scene sequence, proof design, shot/action plan, voiceover construction, on-screen wording, generated clips, edit rhythm, and end-card expression must be materially new against every discoverable prior production. A synonym rewrite, reordered old shots, recolor, crop, speed change, or new music bed does not qualify.
- If prior work cannot be inspected, mark history coverage `不完整` and do not claim the result is historically unique. If no materially new route survives the novelty gate, stop before paid generation and return `待新创意方向` with the collisions listed.
- A KreadoAI Seedance rejection stating that an uploaded image contains a real person is a routing signal: stop retrying that person as `normal`; choose **上传并选择人物形象库**, upload the approved person into the user's character/asset library, poll every created asset to `Active`, and resubmit it as `mediaCategory=asset_library`. Do not default to a built-in `virtual_character` unless the user explicitly selects that alternative. Do not describe a still-image montage as a KreadoAI-generated video.

## Deliverable status

End with one of:

- `可制作`: all production facts exist; compliance or destination checks may still be listed.
- `待补资料`: specific production facts are missing.
- `可投放`: all claims, evidence, offer, CTA/end-card/destination wording, and release checks are verified.

Never label a script `可投放` based only on creative quality.

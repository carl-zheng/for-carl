# Workflow and decision logic

## Contents

- Pre-production brief
- Template choice
- Pain, benefit, proof, trust, and offer mapping
- Five-step team SOP
- Iteration cadence

## Pre-production brief

Create a one-page brief before scripting:

| Field | Decision |
|---|---|
| Product and market | What is sold, where, language |
| Audience identity | Who should stop scrolling |
| Primary scene | Where/when the need becomes urgent |
| Template | Identity / reveal / multi-UGC / data authority |
| S1 identity and action | Who speaks and what the first line does |
| S2 pain type | A user problem or B existing-solution problem |
| Primary benefit | The one thing viewers must remember |
| Supporting benefits | Only benefits relevant to the same audience/scene |
| S3/S4 strategy | Baseline, extend, or repeat with variation |
| Voiceover budget | Narrated seconds, target word count, normal-speed delivery |
| Trust | One or two verifiable sources |
| Offer | One main hook; optional logistics hook |
| End-card alignment | Exact destination wording and five required elements |

If this cannot be expressed compactly, the concept is not ready.

## Mapping logic

### S1 identity × opening action

Identity determines why the speaker is credible or relatable. Useful identity families include real user, designer, verifiable expert, founder, beneficiary, skeptic-turned-user, repeat customer, friend, gift-giver, or profession representative. Identity must be truthful and visually supported where material.

Opening action determines why the viewer stays. It may lock relevance, open curiosity, create conflict, invoke verifiable authority/social proof, or lead with a sensory/result moment. The first shot and first line should perform the same job.

### S2 pain types

- A — user problem: a real frustration, cost, embarrassment, inconvenience, or unmet emotional need. It creates recognition and sells a solution.
- B — existing-solution problem: the old method is slow, awkward, wasteful, unreliable, or otherwise inadequate. It creates a reason to switch and sells replacement.

The chosen pain must be answered directly by the primary benefit in S3/S4. Do not name or disparage a competitor without substantiated grounds.

### S3/S4 timing strategy

- Extend S3/S4 when decision cost is high or the result needs time to prove. Extension means more angles, steps, or evidence for the same main benefit—not an unrelated feature list.
- Repeat the core message for simple, impulse-driven products with one strong memory point. Keep the wording stable while changing scene, camera angle, operator, or proof condition.
- Borrow time first from S2 or S5; keep the total within the chosen placement limit.

### Trust sources

Choose one or two:

- A third-party authority: certifications, tests, publications, awards. Show a verifiable original source or number.
- B social proof: genuine reviews, user footage, rating or sales data.
- C risk reversal: real refund, warranty, trial, or service commitment with a live redemption path.
- D identity/emotion: authentic brand story, origin, heritage, local identity, charity, or family legacy. This has elevated substantiation risk.

C is often the safest first test when the business truly supports it. Never fabricate any trust source.

### Offer hooks

Choose one main hook from price, personal/exclusive, shipping/threshold, gift/bundle, or gamified/reveal. Optionally add one shipping/threshold hook. Verify exact discount, quantity, threshold, duration, gift value, and whether a supposedly exclusive offer is actually exclusive and reproduced on the end card.

## Team SOP

1. Pre-production meeting: select template, audience/identity, pain, primary benefit, trust, offer, and S3/S4 timing.
2. Fill all six cards: shot, subtitle, and voiceover are required for each stage.
3. Align video CTA, end-card title, and live destination activity word for word. Archive evidence for the live terms.
4. Generate voiceover at normal speed, measure its actual duration, then review once muted for visual/subtitle comprehension and once with sound for natural rhythm and fit.
5. Launch and iterate using controlled creative dimensions.

## Lifecycle conventions

The source manual treats roughly one month as a typical AppLovin creative window and suggests small iterations every 2–3 days and larger changes every 7–10 days; Facebook is noted as often shorter at 1–2 weeks. Treat these as team operating baselines, not guaranteed platform facts. Use current campaign data when available. Create at least three S1 variants around the same primary benefit to test audience coverage.

New library entries should start as `验证中`, become `已验证` only after the team's agreed performance test, and be retired after repeated failure under comparable conditions. Preserve the test context rather than treating a line as universally proven.

# KreadoAI Seedance Scene + Uploaded Character Library

Use this route when KreadoAI must generate advertising footage containing a consistent person. It is the required recovery path when a person submitted as a normal image is rejected by the “contains a real person” filter.

## Correct recovery choice

After a real-person rejection, select **上传并选择人物形象库**. Do not keep resubmitting the person as `normal`, and do not automatically replace the requested person with a platform built-in virtual character.

The recovered Seedance request should separate:

- scene/product references: `mediaCategory=normal`;
- the uploaded and activated person reference: `mediaCategory=asset_library`.

Use `virtual_character` only when the user explicitly chooses a KreadoAI built-in character instead of uploading/selecting a person from their own character library.

## Required upload and activation sequence

1. Call `list_seedance_asset_library_groups` and select the intended character/asset group. Retain its `platformGroupId`.
2. Call `create_seedance_asset_library_asset` once for each approved person image:
   - `platformGroupId`: selected group;
   - `assetType`: `Image`;
   - use `assetFileId` when the image is already stored in KreadoAI, otherwise use `assetInput` with a public URL or image base64.
3. Immediately call `get_seedance_asset_library_asset_detail` for every returned `platformAssetId`.
4. Continue polling each asset every 5–10 seconds until `Active`, `Failed`, or `Timeout`. Never substitute `list_seedance_asset_library_assets` for this refresh.
5. Only an `Active` character-library asset may be used for video generation.
6. Map the activated asset to Seedance input:
   - `mediaCategory`: `asset_library`;
   - `assetId`: returned `platformAssetId`;
   - `fileId`: `assetFileResponse.assetFileId` when returned;
   - `url`: `assetFileResponse.fileUrl` when returned.

## Seedance multi-reference submission

Submit `submit_seedance_video_with_references`. Put clean scene/product images and the activated person-library asset in `referenceImages`, then reference every required item in the prompt by its one-based list position.

```json
{
  "referenceImages": [
    {
      "mediaCategory": "normal",
      "url": "PUBLIC_PRODUCT_OR_SCENE_URL"
    },
    {
      "mediaCategory": "asset_library",
      "assetId": "PLATFORM_ASSET_ID",
      "fileId": 123456,
      "url": "ACTIVE_ASSET_FILE_URL"
    }
  ]
}
```

The prompt must contain `@图片1` and `@图片2` when both references are required. Numbering follows the order within `referenceImages`, starting at 1.

## Product and scene constraints

- Keep verified product construction visible in the scene/product reference.
- If the rejected image mixes the person and product, create a clean product/scene reference and upload the approved person separately to the character library.
- Do not imply the library person is wearing the advertised garment unless the generated result preserves the verified garment accurately.
- Prefer one simple action per 4–8 second clip to reduce face, hand, garment, and product drift.

## Generation defaults

- `model`: `Doubao-seedance-2` for final quality.
- `ratio`: `9:16`.
- `resolution`: test at `720P`; move to `1080P` only after the reference combination succeeds.
- `durationSeconds`: normally 4–8 seconds, never more than 15.
- `generateAudio`: false when narration will be added in post.
- `generateCount`: 1 for the first paid test.

## Failure routing and cost control

- Test one scene + activated character-library combination before batch generation.
- If asset creation returns `Processing`, do not submit video early; poll detail until `Active`.
- For multiple uploaded images, every `platformAssetId` must independently reach a terminal status.
- Stop after two materially corrected submission failures and report the exact error and returned charge/refund state.
- Do not convert a failed Seedance batch into a still-image montage while claiming requested video production succeeded.

## Delivery truthfulness

- **Uploaded character-library asset:** the user's selected person stored and activated in the private KreadoAI asset library.
- **Built-in virtual character:** a different optional source; never substitute it silently.
- **KreadoAI Seedance video:** moving footage returned by `batch_get_video_generation_detail`.
- **Locally composited final:** KreadoAI-generated clips plus voiceover, captions, verified offer, and end card.

Only call the final “KreadoAI-produced video” when actual Seedance-generated footage is present.

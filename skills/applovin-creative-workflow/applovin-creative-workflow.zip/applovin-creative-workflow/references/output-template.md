# Deliverable template

Use only the sections needed by the request.

## A. Creative strategy

- Product / market / language:
- Canonical product key / equivalent URLs:
- History sources inspected:
- Prior concepts and assets excluded:
- Placement / duration / aspect ratio:
- Audience identity and primary scene:
- Narrative template and rationale:
- S2 pain type:
- Primary benefit:
- Supporting benefits:
- Trust evidence:
- Exact offer:
- S3/S4 strategy:
- Creative hypothesis:
- Novelty hypothesis versus every prior production:

## B. Six-stage script

| Stage | Time | Shot and action | On-screen text | Voiceover | Purpose/evidence |
|---|---:|---|---|---|---|
| S1 Hook | 0–3s | | | | |
| S2 Pain | 3–7s | | | | |
| S3 Reveal | 7–15s | | | | |
| S4 Proof | 15–25s | | | | |
| S5 Trust + offer | 25–32s | | | | |
| S6 CTA | 32–37s | | | | |

Adjust timecodes when using an approved extension or placement variant; preserve the stage purpose.

## C. Production notes

- Required people/locations/props:
- Product actions and proof shots:
- Framing and CTA safe area:
- Subtitle style and readability:
- Voiceover performance:
- Narrated seconds / target words / final words:
- Requested rate / actual audio duration / effective WPM:
- Voiceover fit status:
- Assets/evidence that must be supplied:

## D. End-card handoff

- Product image/action:
- Exact title/CTA:
- Exact offer and conditions:
- Trust element:
- Brand visual:
- Destination wording checked against:

## E. Subtitle package

- Subtitle language/localization:
- Approved subtitle copy by stage:
- SRT file:
- Font/weight/size:
- Base color/highlight/outline:
- Alignment and safe-area notes:
- Reading-speed exceptions:
- Muted-view review result:

## F. Variants

List the controlled dimension for each variant. Prefer three materially distinct S1 tests around the same benefit rather than superficial word swaps.

## G. Historical novelty report

- History coverage: complete / incomplete
- Product match method: canonical URL / SKU / title+brand / official-image match
- Prior project IDs or folders compared:
- Concept-level collisions found and removed:
- Asset reuse check:
- Voiceover similarity review:
- Shot/scene sequence review:
- Subtitle and end-card expression review:
- Final novelty decision: pass / fail / blocked
- New ledger entry written to:

## H. Release status

- Status:
- Passed checks:
- Unresolved checks:
- Claims awaiting evidence:
- Required next action:

# Six-stage script cards

## S1 Hook — 0–3s

Goal: establish “this is for me” or “I need the outcome.”

- Shot: show the person/problem/result immediately; no logo-first opening.
- Text/VO: identity × opening action; concise, native to the market, and completed by the later story.
- Evidence: if identity carries authority, show design work, qualification, order evidence, or authentic environment as relevant.
- Pass: muted viewers understand relevance or the open loop; product/problem is visible; opening subtitle is readable.
- Reject: fake expert/earnings/volume, vague greetings, generic brand intro, or an unresolved bait line.

## S2 Pain — 3–7s

Goal: articulate one reason to keep watching.

- Choose A user problem or B existing-solution problem.
- Use one specific, filmable situation; show the friction instead of describing an abstraction.
- Maintain continuity: S1 selects who; S2 explains why that person stays.
- Pass: the primary benefit in S3/S4 directly resolves this pain.
- Reject: multiple pains, a long misery scene, exaggerated distress, or unsupported competitor attacks.

## S3 Reveal — 7–15s baseline

Goal: make the product and primary benefit unmistakable.

- Show the complete product clearly.
- Include a hand/use action: unpack, hold, attach, fold, assemble, apply, or operate.
- Demonstrate the primary benefit first with a 2–3 second action.
- Supporting features are allowed only with hierarchy and direct relevance to the audience or core scene.
- Extend to about 15–20 seconds when product understanding genuinely requires it, or repeat the main benefit in varied shots for a simple product.
- Reject: static catalog display, equal-weight feature dumping, or unrelated functions.

## S4 Proof — 15–25s baseline

Goal: visually prove the promised result; this is the conversion-heavy section.

- Use 2–3 authentic contexts, normally 2–4 seconds each.
- Include at least one before/after, measured result, real task completion, or visible outcome.
- Muted playback must still communicate the effect.
- Extend to about 20–35 seconds for high-consideration or time-dependent proof.
- Repetition is allowed only with a new scene, angle, person, or condition. Keep the core claim consistent.
- Reject: effect hidden by visual effects, identical-shot replay, unrealistic polish that defeats credibility, or proof unrelated to S2.

## S5 Trust + offer — 25–32s

Goal: remove final doubt and provide a reason to act now.

- Combine one or two verified trust sources with one main offer hook.
- An optional shipping/threshold hook may be layered if it is accurate and useful.
- Show evidence on screen: source, review context, test reference, terms, or policy access as appropriate.
- The offer wording and conditions must match the end card and destination exactly.
- Reject: unverifiable rating/sales/certification/origin/charity claims, inaccessible refund or warranty promises, or a screen crowded with offers.

## S6 CTA — 32–37s

Goal: hand intent to the end card.

- Return to a complete product shot and, where appropriate, a hand/arrow gesture toward the platform CTA area.
- Compose around the actual CTA overlay so it is not covered.
- Use the same CTA promise/title as the end card.
- End on a loopable product/action frame; avoid black-frame hard cuts.
- Do not show a full checkout tutorial.

## End card as stage seven

Submit it with the video rather than after the fact. It needs:

1. Exact offer.
2. Product presentation.
3. Verified trust information.
4. Brand visual identity.
5. CTA.

Choose a direction consistent with the video: offer/scarcity, primary benefit, social proof, before/after, or substantiated comparison. If using a dynamic catalog, verify the current platform implementation and SKU limits rather than relying on an old number.

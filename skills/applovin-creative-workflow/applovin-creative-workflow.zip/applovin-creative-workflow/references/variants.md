# Creative variants

## Four narrative templates

### Identity-led

Best for mother/baby, fitness, pets, professions, commuters, and other distinct groups. S1 names the group, S2 shows its specific pain, S3/S4 demonstrate real use, S5 uses relevant authentic proof/risk reversal and a suitable bundle or threshold offer, and S6 returns to the identity. In broad delivery, the opening acts as creative-level audience selection.

### Suspense/reveal

Best for cleaning, storage, beauty, novelty products, and strong visual contrast. Show the end result in S1, rewind to the “before” in S2, make the product the reversal mechanism in S3, give the most satisfying result enough space in S4, then use verified price/risk reversal and CTA. The initial result and S4 payoff must be the same story.

### Multi-person UGC

Best when authentic creator footage already exists. Start with the strongest clip, widen recognition with another person describing the same pain, show multiple people handling the product, then cut among distinct real outcomes. Add subtitles and reconstruct one coherent narrative; do not mechanically concatenate social clips.

### Data authority

Best for measurable cleaning, durability, capacity, or efficiency. Open with a substantiated data gap, show the common error/old method, reveal one decisive parameter, then run a visible test or comparison. Display the underlying certification/test/report source. Never use invented data authority.

## 60-second rewarded expansion

Use mainly after the product or concept is validated. A 60-second version is not padded 37-second footage; every extension needs new proof, reaction, context, or emotional progression.

Suggested arc:

- S1 0–4s: complete story or stronger suspense opening.
- S2 4–10s: one short pain/old-solution failure scene.
- S3 10–22s: first-use reaction plus 2–3 relevant, prioritized functions if needed.
- S4 22–42s: everyday, extreme, and longer-use proof.
- S5 42–54s: one or two trust sources plus one main offer; give each room.
- S6 54–60s: CTA, loop, and end-card bridge.

For unvalidated new products, default to three distinct 37-second concepts unless the user specifies another test plan.

## Placement adaptation

| Dimension | Interstitial | Rewarded |
|---|---|---|
| Viewer state | Interrupted/passive | Opted in for reward |
| Skip pressure | Often high after early seconds; verify placement | Usually lower; verify placement |
| Typical creative shape | 15–30s, compressed | 30–60s, more proof/story |
| Opening | Immediate identity/scene relevance | Suspense, plot, or contrast can breathe |
| CTA | Short and direct | May connect to the reward/context |

Treat placement mechanics as changeable platform facts and confirm current requirements when they matter. The manual treats 15-second versions as supplemental tests after initial validation, not the default hero asset.

## Fashion and emotional-value products

For clothing, accessories, decor, and products whose value is primarily identity/emotion:

- Sell the experience and changed state, not a parameter recital.
- Let the first ~80% establish recognition and desire; reveal price/offer in the final ~20%.
- S1 names a person and occasion; S2 exposes an emotional gap; S3 reveals the changed state; S4 tells 3–6 short scene stories; S5 uses authentic wearer proof plus a restrained impulse outlet; S6 uses an emotional CTA.
- Keep a human wearing/using the item. Static hanger/rack inventory footage is product-page content, not the main ad form.
- Combine two or three compatible forms: identity story, multi-scene transformation, pain contrast, material/detail tactility, tutorial, authentic UGC, or real street/wear footage.
- Useful English opening families: Statement, POV, Story, and Education. Adapt them natively to audience and scene; do not claim a phrase is proven without campaign context.
- Give an item an experience-based memory name only when it fits the brand and market, e.g. “the reunion dress” or “the vacation jacket.”

Do not open emotional-value ads with a discount by default, inventory-style item rows, or unsupported “luxury/expensive-looking” claims.

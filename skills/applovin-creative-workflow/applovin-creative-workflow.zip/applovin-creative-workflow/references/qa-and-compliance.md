# Release gate, compliance, and review

## Creative release checklist

All required items must pass before marking `可投放`.

- S1: identity × action within 3 seconds; concise readable subtitle; no logo-first/template feel.
- S1: muted opening conveys relevance or a promised outcome; authority/identity has visual evidence.
- S2: one A/B pain, no more than about 5 seconds, concrete and filmable.
- S2→S4: pain, primary benefit, and proof form one continuous cause-and-effect chain.
- S3: complete clear product view plus human handling/use.
- S3: supporting functions are prioritized and relevant to audience/scene.
- S4: understandable without sound; at least two scenes and one clear result/comparison where appropriate.
- S4: repeated message uses new scene/angle/person; no identical replay filler.
- S5: one or two trust sources and one main offer; optional logistics hook only.
- S5: every fact and term is verifiable, current, and archived.
- S5/S6: video CTA, end-card title, and destination activity are word-for-word aligned.
- S6: product-led loopable ending; no black-frame hard cut; CTA overlay remains unobstructed.
- Global: 9:16 unless placement requires otherwise; subtitles throughout; voiceover style matches the requested market and brief.
- Voiceover: copy length is calculated from narrated seconds at 150–165 WPM; generated first at neutral 1.0×; actual duration and naturalness are verified. No sub-0.95 slowdown or time-stretch is used to hide an underwritten script.
- Subtitles: approved screen copy, UTF-8 SRT, timing within final duration, no overlaps, readable speed, maximum two lines, verified UI/CTA safe area, and muted S1–S6 comprehension.
- Global: no complete checkout flow inside the video and no recommendation to pause the winning asset manually.

## Claim substantiation

Require evidence before publishing:

- Ratings, reviews, sales volume, rankings, and testimonials.
- Professional identities, qualifications, earnings, cost savings, and order screenshots.
- Certifications, patents, tests, medical/performance results, and data comparisons.
- Refund, trial, warranty, shipping, delivery, and service promises.
- Discounts, original prices, stock scarcity, timers, gifts, bundles, and exclusivity.
- Country of origin, “made in,” “designed in,” local-brand, charity, heritage, and environmental claims.

Evidence should be traceable by screenshot, URL, source file, report/registration number, or live policy. Match qualifiers and conditions exactly. A claim being visually compelling does not reduce the substantiation requirement.

Do not universalize the source manual's jurisdiction-specific examples. For a real campaign, follow the destination market's current advertising law and platform policy. Browse or use authoritative legal/platform sources when high-stakes compliance accuracy is requested.

## Common review failures and fixes

| Failure | Correction |
|---|---|
| Logo/cold opening | Start with identity × action; introduce brand later |
| Fake authority or income | Remove or replace with documented real identity/evidence |
| Equal-weight feature dump | Select one primary benefit; map support features to audience/scene |
| Pain scene drags | Keep one concrete pain and move to resolution |
| User pain but no reason to switch | Test a truthful B-type old-solution problem |
| Effects obscure reality | Use authentic before/after or result proof |
| S3/S4 rigidly short | Extend proof for high-consideration products |
| Extended section adds random functions | Add depth and angles for the same benefit |
| Repetition becomes replay | Change scene/angle/person while preserving message |
| Offer differs by surface | Copy exact wording from the verified live offer |
| “Exclusive” is universal | Remove exclusivity or create a real reproducible exclusive offer |
| Too many promotions | One main hook plus at most one logistics hook |
| UGC copied without structure | Subtitle and rebuild into S1–S6 narrative |
| CTA rewritten from memory | Copy the approved end-card title verbatim |
| Voiceover sounds slow because copy is short | Add verified useful information, regenerate near 1.0×, then retime subtitles to the locked audio |

## Review response format

For reviews, report:

1. Overall status: `可投放`, `可制作`, or `待补资料`.
2. Stage-by-stage pass/fail with the observable reason.
3. Claim/evidence table: claim, evidence supplied, status, required correction.
4. CTA/end-card/destination exact-text comparison.
5. Highest-impact creative fixes, prioritized.

Do not silently “fix” an unverified commercial term by inventing a safer one. Use a placeholder and request the true term.

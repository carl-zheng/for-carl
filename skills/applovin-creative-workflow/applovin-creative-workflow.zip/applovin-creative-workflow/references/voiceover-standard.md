# Voiceover copy and pacing standard

Use this standard for English voiceover writing, TTS generation, and fitting narration to the final edit. The default performance is an adult female commercial voice with natural energy, clear articulation, and normal conversational-advertising speed.

## Duration-based word budget

Calculate the narration budget before writing:

`target words = narrated seconds × target WPM ÷ 60`

- Default target: **150–165 WPM**; use **158 WPM** for first-pass planning.
- 37 seconds fully narrated: about **90–100 words** (planning target: 97).
- 60 seconds fully narrated: about **145–160 words** (planning target: 158).
- Subtract intentional silent beats, product sound moments, and end-card hold before calculating. A two-second silent beat reduces the 158-WPM budget by about five words.
- Count the final spoken English words, not subtitle lines. Read numerals, symbols, prices, URLs, and abbreviations as they will actually be spoken.

Treat these as fit targets, not permission to add filler. If the verified product facts cannot support the target, allow purposeful visual or sound-only beats and report them explicitly.

## Copy density and content order

Write complete spoken thoughts rather than slogan fragments separated by long pauses. Every added sentence must perform one of these jobs:

1. identify the viewer or problem;
2. explain the product action;
3. name a demonstrable benefit;
4. interpret visible proof;
5. remove a verified objection;
6. state the exact offer or CTA.

When a draft is too short, add useful, supportable information in that order. Add a scene-specific use case, explain what the viewer is seeing, strengthen the cause-and-effect link, or clarify a verified service term. Never pad with repeated adjectives, invented claims, generic hype, or a slower voice.

Keep the opening brisk and the proof section most informative. S5/S6 may be slightly more deliberate for offer comprehension, but should still sound like normal speech.

## Performance direction

- Voice: adult female, natural English, warm and confident, contemporary direct-response style.
- Rate: provider-neutral **1.0×** first pass. After listening, adjustment may stay within **0.98–1.05×**.
- Delivery: connected phrases, light emphasis on the problem, primary benefit, proof result, offer, and CTA.
- Pauses: use punctuation-driven micro-pauses. Reserve longer pauses for a planned reveal, visual proof, product sound, or end-card hold.
- Avoid exaggerated announcer cadence, word-by-word delivery, robotic emphasis, and stretched sentence endings.
- Do not slow below **0.95×** unless the user explicitly requests a slow or accessibility-focused delivery.

Voice choice and accent must follow the requested market. Do not infer a professional identity, testimonial role, or customer status from the voice.

## Generate, measure, and fit

1. Calculate the word budget from narrated seconds.
2. Write the final voiceover and record its word count and planned WPM.
3. Generate at neutral 1.0× and measure the actual audio duration.
4. Listen for natural rhythm; do not approve based on duration alone.
5. Fit with this priority:
   - If audio is too short, first add verified useful copy or restore natural micro-pauses; keep rate near 1.0×.
   - If audio is too long, tighten wording or remove low-value repetition; a small speed increase up to 1.05× is allowed after listening.
   - If the mismatch remains, adjust shot timing or add a deliberate visual/sound-only beat. Do not use heavy time-stretching.
6. Lock the final audio before timing subtitles. Subtitle cues follow the final spoken performance, not the draft timecodes.

Target the narration to finish about **0.3–0.8 seconds** before the video ends when the final frame needs a clean CTA hold. For a longer end-card hold, subtract that hold from narrated seconds at the budgeting stage.

## Required production handoff

Report:

- voice language, accent/market, and performance direction;
- narrated seconds and intentional silent beats;
- final word count and effective WPM;
- provider voice/voice ID when known;
- requested generation rate and actual audio duration;
- any timing adjustment made and why;
- final fit status: `通过`, `需改文案`, or `需重生成`.

## Release gate

Pass only when all are true:

- Copy falls within the calculated range or every deviation has an intentional visual/audio reason.
- The voice sounds natural at normal speed and remains intelligible on a phone speaker.
- No section uses slow delivery merely to occupy time.
- Product names, prices, discount conditions, and CTA are pronounced correctly.
- Audio ends cleanly without clipped words and leaves the planned CTA/end-card hold.
- Subtitle timing has been regenerated or verified against the locked audio.

# Historical uniqueness and repeat-product control

Use this mechanism whenever a request contains a product URL or may repeat a product produced before. Its purpose is to prevent creative self-duplication across all prior batches, not merely within the current batch.

## 1. Resolve the canonical product identity

Create a stable `product_key` before ideation. Match in this order:

1. Canonicalized product URL: lowercase host, remove fragments and tracking parameters, normalize trailing slash, and preserve the product path/handle.
2. Stable product or variant ID/SKU from structured page data when available.
3. Brand + normalized product title.
4. Official-image equivalence: the same official source URLs, downloaded image hashes, or clearly identical product imagery.

Treat redirects, localized URLs, tracking links, renamed listings, color-variant URLs, and separate pages using the same official product imagery as the same product unless the merchandise is materially different.

## 2. Discover all prior work

Search the active workspace and configured output roots for the canonical URL, product handle, product ID/SKU, normalized title, and official image names or hashes. Inspect, when present:

- creative packages, scripts, briefs, production plans, manifests, QA reports, subtitles, and end-card copy;
- raw clips, generated scene images, voiceovers, final videos, contact sheets, and file hashes;
- the persistent ledger at `creative-history/<product_key>.md` or the closest existing product history record.

Do not stop after finding the latest project. Build an inventory covering every discoverable prior production. Record the searched roots and whether coverage is complete.

## 3. Build the exclusion set

Summarize each prior creative as a compact signature:

- audience and use occasion;
- primary promise or emotional payoff;
- narrative template and S1 hook mechanism;
- pain/conflict and proof method;
- scene order, location family, performer role, product actions, camera language, and transition device;
- voiceover opening, argument structure, memorable phrasing, offer framing, CTA, and end-card title;
- subtitle treatment and information order;
- IDs, paths, hashes, or contact sheets for generated images, clips, audio, and finals.

These signatures become exclusions for the new run. Verified product facts, real price, official variants, mandatory legal copy, logo, and established brand typography are truth/identity constraints and are not considered creative duplication by themselves.

## 4. Design a materially new route

A repeat-product concept must change the organizing idea, not just surface wording. Before production, require a new combination across all of these execution layers:

1. Different audience tension or use occasion.
2. Different core creative promise or emotional payoff.
3. Different hook mechanism and opening action.
4. Different narrative progression and proof method.
5. Different scene sequence, product actions, framing plan, and transition grammar.
6. Newly written voiceover with a different opening, reasoning path, sentence construction, and closing line.
7. Different on-screen information sequence and end-card expression, while preserving mandatory brand and offer facts.

Changing only synonyms, line order, color grade, wardrobe, model identity, music, crop, playback speed, or one background is insufficient. Combining several old concepts into a montage is also insufficient.

When producing two concepts in one batch, each must pass against both the historical set and the other new concept.

## 5. Pre-generation novelty gate

Before any paid or irreversible generation, create a comparison table with the new concept beside every prior signature. Fail the concept if any prior production shares the same organizing promise plus substantially the same hook/narrative/proof route, even when the wording differs.

Also reject a concept when three or more major execution layers are substantially reused from the same prior production. Revise the concept and rerun the comparison. If no new route survives, stop with `待新创意方向`; do not spend generation credits.

## 6. Asset-level no-reuse rule

For a repeat product, create new scene images and new video clips. Do not reuse prior generated shots, raw clips, voiceover audio, subtitle events, price-card animation, end-card animation, or final-video segments unless the user explicitly requests reuse.

After rendering:

- compare final and raw-asset file hashes against the ledger;
- visually compare sampled/contact-sheet frames to prior contact sheets;
- check that the scene order and motion pattern did not converge back to an old edit;
- confirm the new voiceover and burned-in subtitle wording match the approved new route.

Identical hashes are an automatic failure. Near-identical visuals or edits require replacement even if the binary hashes differ.

## 7. Persist the ledger

Before delivery, append a record under `creative-history/<product_key>.md`. Create it when missing. Include:

- date, project path, canonical and equivalent URLs;
- product IDs/SKUs and official-image identifiers available at production time;
- concept signature for every delivered variant;
- full voiceover opening and closing lines;
- scene/shot sequence summary;
- subtitle/price-card/end-card expression;
- generation task IDs, source paths, final paths, and hashes;
- novelty comparison result and any intentionally stable truth/brand elements.

Never overwrite earlier entries. The ledger is the cross-project memory used by later runs.

## 8. Delivery language

Report one of:

- `历史去重通过`: all discoverable history inspected; concept and assets are materially new.
- `历史覆盖不完整`: some prior roots or assets could not be inspected; do not promise global uniqueness.
- `历史去重失败`: the result collides with prior work and must not be delivered as a new creative.
- `待新创意方向`: no sufficiently different route remains; generation was stopped before spending credits.

# Subtitle production standard

Use this standard for script preparation, KreadoAI production handoff, and final-render review. Subtitles serve muted comprehension and conversion; they are not a verbatim transcript by default.

## Required deliverables

1. `subtitle-copy`: approved on-screen wording mapped to S1–S6.
2. `subtitles.srt`: UTF-8 timed subtitle file with sequential cue numbers.
3. `subtitle-style`: font category, weight, size, color, outline/shadow, highlight color, alignment, and safe-area placement.
4. `subtitle-review`: pass/fail report against the actual rendered video.

When a platform burns subtitles into the video, still keep the SRT as the editable source of truth. If KreadoAI provides an SRT export, compare it with the approved copy and correct timing/text before final delivery.

## Copy rules

- Preserve product facts and meaning, but compress speech into screen-readable phrases.
- One cue should express one semantic unit. Break at punctuation, clause, or shot change; never split a product name, number with its unit, offer phrase, or fixed expression across cues.
- Keep S1 especially short. The manual's Chinese opening baseline is no more than 12 characters when practical.
- Prefer one line; allow two lines only when needed. Do not use more than two lines in a standard 9:16 ad.
- Keep line lengths visually balanced. As a working baseline, target about 10–16 Chinese characters per line or roughly 28–36 Latin characters, then adjust for font size and device preview.
- Keep terminology, capitalization, currency, units, discount, CTA, and brand spelling consistent with the verified product page and end card.
- Do not subtitle filler words unless they carry personality or timing. Do not add claims that are absent from the approved script.
- For bilingual delivery, make separate localized subtitle files by default. Use two-language stacked subtitles only when the user explicitly needs them and the safe area remains readable.

## Timing rules

- Time against the final voice track or final render, not estimated script duration.
- Cue in near the start of the spoken phrase and cue out after comprehension; avoid showing the answer materially before the voice or visual reveal.
- Baseline minimum duration: about 0.8 seconds for a short cue. Baseline maximum: about 4 seconds unless a deliberate hold is needed.
- Use a small visual gap between unrelated cues when speech permits; avoid flicker caused by extremely short gaps.
- At a hard shot change, move the cue boundary to the cut unless the sentence intentionally bridges scenes.
- Maintain comfortable reading speed. Working targets: roughly 4–8 Chinese characters/second or 12–17 Latin characters/second. Slow down for numbers, unfamiliar product names, legal qualifiers, or offer conditions.
- S5 offer terms must remain visible long enough to read. S6 CTA should persist through the clickable/end-card bridge rather than flashing briefly.
- SRT timestamps use `HH:MM:SS,mmm --> HH:MM:SS,mmm`, must not overlap, and must stay within the final video duration.

## Visual style

- Default production style is the locked premium ASS system in `../assets/premium-subtitles-template.ass`. Copy and adapt that template for every ordinary AppLovin deliverable unless the user explicitly requests a different subtitle identity.
- Use a bold, high-legibility sans-serif appropriate to the target language. Confirm the font license and glyph coverage.
- Default to centered lower-third placement, but move text when it covers the product, face, proof action, price, or platform CTA.
- Keep subtitles inside the verified placement safe area. Because platform UI can change, validate with a current placement preview or overlay; do not rely on a permanent pixel coordinate.
- For a 9:16 working canvas, reserve the upper and lower UI zones and keep key subtitle content in the central visual-safe region. The bottom CTA area has priority over subtitle placement.
- Ensure strong contrast under every shot. Use a restrained outline, shadow, or semi-transparent backing rather than changing style unpredictably between scenes.
- Use one base color and at most one controlled highlight color. Highlight only the primary benefit, proof result, price/offer, or CTA—not entire sentences.
- Avoid covering mouths for avatar/UGC footage and avoid covering hands/product interactions in S3/S4.
- Keep size, line spacing, alignment, and margins consistent across the asset and its variants.

## Locked premium subtitle system

Use these defaults for finished AppLovin videos:

- No large solid or semi-transparent background block behind ordinary S1–S4 subtitles.
- White bold sans-serif with a four-pixel dark outline and restrained shadow.
- One controlled campaign accent color; for product-led fashion creative, default to denim blue. Adapt the accent to the product palette only when contrast remains strong.
- Highlight one result, benefit, or scene phrase per cue; do not color the whole sentence.
- Use short phrase-level cues rather than paragraph transcription.
- Animate each cue with a 100–150 ms fade and subtle 94–100% scale-in. No bounce, spin, typewriter, or karaoke effect unless explicitly requested.
- S1 uses a two-level hook: setup line plus larger highlighted result phrase.
- S3 uses compact benefit pairs or a single benefit statement.
- S4 may use numbered scene markers such as `01 / MORNING`, `02 / WORK`, `03 / EVENING` when the creative demonstrates multiple contexts.
- S5 ordinary subtitles stop when the dedicated offer card appears. Do not duplicate the same price or discount in both systems.
- S6 ordinary subtitles stop when the end card/CTA appears. The CTA belongs to the end-card system.
- Move subtitle position when it conflicts with a face, product demonstration, or platform UI. The template's lower placement is a default, not permission to cover the subject.

The approved test reference uses ASS at 1080×1920 with `PlayResX=1080`, `PlayResY=1920`. Scale font size and positions proportionally for other resolutions. Preserve the external UTF-8 SRT as the complete accessible/editable text source even when the burned-in ASS intentionally omits S5/S6 duplicates.

## Stage-specific subtitle jobs

| Stage | Subtitle job |
|---|---|
| S1 | Identify audience or open the result gap immediately |
| S2 | State one concrete pain, without a paragraph |
| S3 | Name the primary benefit as the action proves it |
| S4 | Label result/comparison/scene; let the image carry the proof |
| S5 | Show verified trust and the exact offer with necessary conditions |
| S6 | Copy the approved end-card CTA wording exactly |

## SRT quality gate

- Cue numbers are continuous and start at 1.
- UTF-8 text renders without garbled characters.
- No overlaps, negative time, reversed timestamps, or cues outside video duration.
- No orphan punctuation or bad semantic line breaks.
- All spoken commercial claims have matching approved wording; required visual-only claims are also captioned when muted comprehension depends on them.
- Product name, price, currency, percentage, quantity, shipping threshold, gift, dates, and CTA match approved sources exactly.
- Subtitle position does not collide with platform UI, face, product, proof action, or end-card CTA.
- Muted viewing still communicates S1 relevance, S2 pain, S3 benefit, S4 result, S5 offer, and S6 action.

## KreadoAI handoff

- Keep voiceover text and subtitle copy as separate fields; do not assume TTS text is the final subtitle text.
- Generate or approve the voice track first, then align SRT timing to the audio/render.
- If scenes are generated separately, create scene-local timing first and then offset cues against the assembled master timeline.
- After regeneration, retime the affected cues; never reuse timestamps merely because the script text did not change.
- Archive the approved SRT and style specification alongside the final video URL and generation task IDs.
- Generate clean KreadoAI footage without baked captions. Apply the premium ASS layer only after picture lock, then inspect a one-frame-per-second contact sheet and the full phone-size playback.
